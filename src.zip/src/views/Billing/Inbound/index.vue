<template>
  <div class="products h-full flex flex-col" v-show="!showHistory">
    <div class="flex justify-between items-center mb-4 flex-shrink-0">
      <div>
        <div class="flex items-center gap-1 line-height-22px">
          <div class="text-#000 text-28px line-height-36px">Billing</div>
          <div class="text-#9A9A9A text-20px pt-1">/Inbound</div>
        </div>
        <div class="text-14px text-#6B6B6B">
          Analyze inbound processing costs and warehouse-related expenses.
        </div>
      </div>
      <div class="flex items-center gap-3">
        <el-button type="default" size="large" @click="showHistory = true">
          <span class="flex items-center gap-1">
            <Icon icon="svg-icon:file-dollar" color="#16215B" />
            <span class="text-16px text-#16215B">Transaction History</span>
          </span>
        </el-button>
        <el-button type="primary" size="large" @click="handleAddCredit">
          <span class="flex items-center gap-1">
            <Icon icon="svg-icon:circle-dollar" color="#fff" />
            <span>Recharge Credit</span>
          </span>
        </el-button>
      </div>
    </div>

    <div class="w-full h-20px flex justify-end">
      <el-button
        link
        class="!text-gray-600 !px-2"
        @click="showCards = !showCards"
      >
        <span class="flex items-center gap-1">
          <Icon
            :icon="showCards ? 'svg-icon:eye-slash' : 'svg-icon:eye'"
            color="#16215B"
          />
          <span>{{ showCards ? "Hide Data" : "View Data" }}</span>
        </span>
      </el-button>
    </div>

    <div
      v-show="showCards"
      class="grid grid-cols-1 lg:grid-cols-3 gap-4 mb-4 box"
    >
      <div
        class="bg-white rounded-xl border border-gray-100 shadow-card p-6 flex animate__animated animate__fadeInUp"
      >
        <div class="font-semibold">
          <div class="whitespace-nowrap text-[16px] line-height-24px">
            Balance
            <el-tooltip
              class="box-item"
              effect="dark"
              content="!!!!"
              placement="top-start"
            >
              <Icon icon="svg-icon:circle-question" color="#9A9A9A" />
            </el-tooltip>
          </div>
          <div class="flex items-center gap-1 text-[14px]">
            <Icon icon="svg-icon:circle-arrow-up" color="#0211A3" />
            <div class="text-#0211A3">$5,250</div>
            <div class="text-#9A9A9A">/ $10,500</div>
          </div>
        </div>

        <div ref="storageChartRef" class="w-full h-44 py-4"></div>
      </div>

      <div
        class="bg-white p-6 rounded-xl shadow-sm border border-gray-100 h-59.5 animate__animated animate__fadeInUp flex flex-col flex-justify-around"
      >
        <div class="flex justify-between items-center mb-6">
          <div>
            <div class="text-lg font-bold text-#000">
              Reserved Credits
              <el-tooltip
                class="box-item"
                effect="dark"
                content="!!!!"
                placement="top-start"
              >
                <Icon icon="svg-icon:circle-question" color="#9A9A9A" />
              </el-tooltip>
            </div>
            <div class="text-xs text-#0211A3 mt-0.5 flex items-center gap-2">
              <Icon
                icon="material-symbols:arrow-circle-up-outline-rounded"
                width="16"
                height="16"
                class="text-gray-400"
                color="#0211A3"
              />
              <span class="text-[14px]">{{ price }}</span>
            </div>
          </div>
          <el-button type="primary" size="large" class="!w-[128px] !rounded-2" @click="handleAddCredit">
            <template #icon>
              <Icon
                icon="mage:dollar"
                width="24"
                height="24"
                style="color: #fff"
              />
            </template>
            Recharge</el-button
          >
        </div>
        <div class="w-full min-h-0">
          <div
            v-for="item in progressItems"
            :key="item.label"
            class="w-full mt-4.5"
          >
            <el-row justify="space-between" class="text-xs text-gray-600 mb-1">
              <el-col :span="12">{{ item.label }}</el-col>
              <el-col
                :span="12"
                class="text-right"
                :style="{ color: item.color }"
                >${{ item.value }}</el-col
              >
            </el-row>
            <el-progress
              :percentage="item.percent"
              :stroke-width="16"
              :show-text="false"
              :color="item.color"
              :style="{ '--el-progress-bg-color': '#e5e7eb' }"
            />
          </div>
        </div>
      </div>

      <div
        class="card position-relative w-full animate__animated animate__fadeInUp"
      >
        <div
          class="position-absolute bottom-0 left-0 w-full h-85% box-border bg-[url('@/assets/svgs/bo-lang-blue.svg')] bg-no-repeat bg-contain bg-bottom"
        />
        <div
          class="flex items-center justify-between mb-2 p-6 position-absolute w-full box-border"
        >
          <div class="text-sm font-semibold opacity-80">
            <div class="text-16px">Total Savings</div>
            <div class="flex items-center gap-1">
              <Icon icon="svg-icon:circle-arrow-up" color="#BDBDBD" />
              <div class="text-#BDBDBD">12% vs. Traditional Method</div>
            </div>
          </div>
          <div class="flex items-center justify-end mb-1">
            <span class="text-3xl font-bold">$2,430</span>
          </div>
        </div>
      </div>
    </div>

    <ProductFilter ref="filterRef" :company="authStore.currentCompany ?? undefined" @search="handleFilterSearch" />

    <div class="flex-1 min-h-0 rounded-xl overflow-hidden">
      <BaseTable
        :data="tableData"
        :columns="columns"
        :loading="loading"
        :pagination="true"
        :total="total"
        v-model:page="page"
        v-model:limit="limit"
        @pagination-change="fetchData"
      >
        <template #expand="{ row }">
          <div class="py-4 px-6 bg-#F7F7F7">
            <div class="bg-#fff rounded-lg border border-gray-200">
              <div
                class="flex justify-between items-center px-6 py-3 !border-b-1.5 border-0 border-solid border-#ECECEC"
              >
                <div>
                  <div class="flex items-center gap-3 mb-2">
                    <span class="text-lg font-bold text-gray-900">
                      {{ row.inboundId }}
                    </span>
                  </div>
                </div>
                <div class="text-left text-sm flex items-center gap-12">
                  <div>
                    <span class="text-gray-500 mr-2">Create</span>
                    <span class="text-gray-900 font-semibold">dd/mm/yyyy</span>
                  </div>
                  <div>
                    <span class="text-gray-500 mr-2">Forecasted</span>
                    <span class="text-gray-900 font-semibold">dd/mm/yyyy</span>
                  </div>
                  <div>
                    <span class="text-gray-500 mr-2">Completed</span>
                    <span class="text-gray-900 font-semibold">dd/mm/yyyy</span>
                  </div>
                </div>
              </div>
              <div class="px-6 py-4">
                <div
                  class="border border-gray-200 rounded-lg overflow-hidden mb-4 border-solid"
                >
                  <div
                    class="grid grid-cols-3 bg-gray-50 border-b border-gray-200 text-sm font-medium text-gray-900 text-center border-solid border-0"
                  >
                    <div
                      class="p-3 border-r border-gray-200 border-solid border-0"
                    >
                      Pallet
                    </div>
                    <div
                      class="p-3 border-r border-gray-200 border-solid border-0"
                    >
                      Box
                    </div>
                    <div class="p-3 border-solid border-0">
                      Scan and Put Away
                    </div>
                  </div>

                  <div
                    class="grid grid-cols-9 text-xs text-gray-500 bg-gray-50 border-b border-gray-200 text-center border-solid border-0"
                  >
                    <div
                      class="p-2 border-r border-gray-200 border-solid border-0"
                    >
                      QTY
                    </div>
                    <div
                      class="p-2 border-r border-gray-200 border-solid border-0"
                    >
                      Price
                    </div>
                    <div
                      class="p-2 border-r border-gray-200 border-solid border-0"
                    >
                      Subtotal
                    </div>
                    <div
                      class="p-2 border-r border-gray-200 border-solid border-0"
                    >
                      QTY
                    </div>
                    <div
                      class="p-2 border-r border-gray-200 border-solid border-0"
                    >
                      Price
                    </div>
                    <div
                      class="p-2 border-r border-gray-200 border-solid border-0"
                    >
                      Subtotal
                    </div>
                    <div
                      class="p-2 border-r border-gray-200 border-solid border-0"
                    >
                      QTY
                    </div>
                    <div
                      class="p-2 border-r border-gray-200 border-solid border-0"
                    >
                      Price
                    </div>
                    <div class="p-2 border-solid border-0">Subtotal</div>
                  </div>

                  <div
                    class="grid grid-cols-9 text-sm text-gray-900 bg-white text-center"
                  >
                    <div class="p-4 border-r border-gray-200">
                      {{ row.palletQty?.toString().padStart(2, "0") || "02" }}
                    </div>
                    <div class="p-4 border-r border-gray-200">
                      {{ row.palletPrice || "$0,00" }}
                    </div>
                    <div class="p-4 border-r border-gray-200">
                      {{ row.palletSubtotal || "$0,00" }}
                    </div>
                    <div class="p-4 border-r border-gray-200">
                      {{ row.boxQty?.toString().padStart(2, "0") || "03" }}
                    </div>
                    <div class="p-4 border-r border-gray-200">
                      {{ row.boxPrice || "$0,00" }}
                    </div>
                    <div class="p-4 border-r border-gray-200">
                      {{ row.boxSubtotal || "$0,00" }}
                    </div>
                    <div class="p-4 border-r border-gray-200">
                      {{ row.scanQty?.toString().padStart(2, "0") || "04" }}
                    </div>
                    <div class="p-4 border-r border-gray-200">
                      {{ row.scanPrice || "$0,00" }}
                    </div>
                    <div class="p-4">{{ row.scanSubtotal || "$0,00" }}</div>
                  </div>
                </div>

                <div class="flex justify-between items-center">
                  <span class="text-lg font-bold text-gray-900">Total</span>
                  <span class="text-lg font-bold text-gray-900">{{
                    row.grandTotal
                  }}</span>
                </div>
              </div>
            </div>
          </div>
        </template>

        <template #inboundId="{ row }">
          <div class="flex items-center gap-2">
            <span class="font-medium text-gray-900">{{ row.inboundId }}</span>
          </div>
        </template>

        <template #actions="{ row }">
          <div class="flex flex-col items-center">
            <el-popover
              placement="bottom-start"
              trigger="click"
              popper-class="!p-0 !px-2 !min-w-auto !rounded-lg !w-auto"
              :show-arrow="false"
            >
              <template #reference>
                <el-button class="w-8 h-8">
                  <Icon icon="svg-icon:ellipsis-vertical" color="#16215B" />
                </el-button>
              </template>
              <div class="py-2 px-1 flex flex-col">
                <el-button
                  link
                  class="!text-blue-600 !font-semibold w-full !justify-start hover:!bg-#F4F6FA !h-9 !px-2"
                >
                  <span class="flex justify-center items-center gap-2">
                    <Icon icon="svg-icon:shopping-cart" />
                    View Order
                  </span>
                </el-button>
                <el-button
                  link
                  class="!text-red-600 !font-semibold w-full !justify-start hover:!bg-#F4F6FA !h-9 !ml0 !px2"
                >
                  <span class="flex justify-center items-center gap-2">
                    <Icon icon="svg-icon:headphones" />
                    Contact Support
                  </span>
                </el-button>
              </div>
            </el-popover>
          </div>
        </template>
      </BaseTable>
    </div>

    <ProductDetail
      v-model:visible="detailVisible"
      :product-id="currentProductId"
      @save="handleSaveProduct"
      @delete="fetchData"
      @close="detailVisible = false"
    />

    <AddCredit v-model:visible="addCreditVisible" @success="loadData" />
  </div>
  <div v-if="showHistory">
    <History ref="historyRef" @close="showHistory = false" />
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted, reactive, onBeforeUnmount, nextTick } from "vue";
import {
  Plus,
  Edit,
  ShoppingCart,
  Box,
  CreditCard,
  Document,
  Message,
  Lock,
  CircleCheck,
  View,
} from "@element-plus/icons-vue";
import * as echarts from "echarts";
import ProductFilter from "./components/ProductFilter.vue";
import ProductDetail from "./components/productDetail.vue";
import AddCredit from "./components/addCredit.vue";
import History from "./components/History.vue";
import { exportInventoryProducts, getInventoryProducts } from "@/api/inventory";
import {
  getOutboundStats,
  getBillingNotifications,
  getBillingRecentOrders,
  markBillingNotificationAsRead,
} from "@/api/billing";
import { getInboundList } from "@/api/billing/inbound";
import { parseOmsBillingListResult } from "@/utils/frappeResponse";
import { getDefaultMonthStartToToday } from "@/utils/dateRange";
import { useAuthStore } from "@/store/modules/auth";
import { ElMessage } from "element-plus";
import { MoreFilled } from "@element-plus/icons-vue";
import productImage from "@/views/icon/yf.png";

const authStore = useAuthStore();

const price = ref("$0");
const editVisible = ref(false);
const progressItems = ref<any[]>([]);
const notifications = ref<any[]>([]);
const recentOrders = ref<any[]>([]);

const showHistory = ref(false);
// Product Detail State
const detailVisible = ref(false);
const currentProductId = ref<string | undefined>(undefined);
// Add Credit State
const addCreditVisible = ref(false);

const filterRef = ref();
const currentFilters = ref({});

const getIconComponent = (type: string) => {
  const map: Record<string, any> = {
    ShoppingCart,
    Box,
    CreditCard,
    Document,
    Message,
    Lock,
  };
  return markRaw(map[type] || Message);
};
const loadData = async () => {
  const company = authStore.currentCompany ?? (await authStore.ensureCompany()) ?? "";
  if (!company) return;
  const f = currentFilters.value as Record<string, any>;
  const [period_start, period_end] =
    f?.period_start && f?.period_end
      ? [String(f.period_start), String(f.period_end)]
      : getDefaultMonthStartToToday();
  try {
    const [statsRaw, notifRes, ordersRes] = await Promise.all([
      getOutboundStats({ company, period_start, period_end }).send(),
      getBillingNotifications(),
      getBillingRecentOrders(),
    ]);

    const msg = (statsRaw as any)?.message ?? statsRaw;
    const summary = msg?.summary ?? {};
    const byMonth = Array.isArray(msg?.by_month) ? msg.by_month : [];
    const latest = byMonth[0] || {};
    const rev = summary.total_revenue_usd ?? latest.total_revenue_usd ?? 0;
    const orders = summary.total_orders ?? latest.total_orders ?? 0;
    const avg = summary.avg_order_value_usd ?? latest.avg_order_value_usd ?? 0;
    price.value = `$${typeof rev === "number" ? rev.toLocaleString() : "0"}`;
    progressItems.value = [
      { label: "Total Revenue", value: Number(rev), total: Number(rev) || 100, percent: 100, color: "#0211A3", prefix: "$" },
      { label: "Total Orders", value: Number(orders), total: Math.max(Number(orders), 1), percent: 100, color: "#0211A3", prefix: "" },
      { label: "Avg. Order Value", value: Number(avg), total: Math.max(Number(avg), 1), percent: 100, color: "#0211A3", prefix: "$" },
    ];

    notifications.value = (Array.isArray(notifRes) ? notifRes : []).map((n: any) => ({
      ...n,
      icon: getIconComponent(n.iconType),
    }));

    recentOrders.value = (ordersRes.list || []).map((o: any) => ({
      ...o,
      image: o.image && String(o.image).includes("placeholder") ? productImage : o.image,
    }));
  } catch (error) {
    console.error("Failed to load dashboard data:", error);
  }
};

const handleViewDetail = (row: any) => {
  currentProductId.value = row.id;
  detailVisible.value = true;
};

const handleMoreActions = (row: any) => {
  // Logic for more actions (e.g. dropdown menu)
  console.log("More actions for", row);
};

const handleAddCredit = () => {
  addCreditVisible.value = true;
};

const handleImport = async () => {
  try {
    const res = await exportInventoryProducts({});
    if (res?.url) {
      window.open(res.url, "_blank");
      ElMessage.success("Export started successfully");
    }
  } catch (error) {
    ElMessage.error("Export failed");
  }
};

const handleSaveProduct = async (data: any) => {
  // Mock save logic
  console.log("Saved:", data);
  detailVisible.value = false;
  fetchData();
};

const handleFilterSearch = (params: any) => {
  currentFilters.value = params;
  page.value = 1;
  loadData();
  fetchData();
};

const columns = [
  { type: "selection", width: 50 },
  { type: "expand", width: 50, slot: "expand" },
  { label: "Inbound ID", slot: "inboundId", minWidth: 200 },
  {
    label: "Completion Date",
    prop: "completionDate",
    minWidth: 150,
    align: "center",
  },
  { label: "Warehouse", prop: "warehouse", minWidth: 150, align: "center" },
  { label: "Total Amount", prop: "totalAmount", minWidth: 150, align: "right" },
  {
    label: "Actions",
    slot: "actions",
    width: 80,
    fixed: "right",
    align: "center",
  },
];

// Data Logic
const tableData = ref([]) as any;
const loading = ref(false);
const total = ref(0);
const page = ref(1);
const limit = ref(10);
const invChartRef = ref<HTMLElement | null>(null);
const storageChartRef = ref<HTMLElement | null>(null);
const valueChartRef = ref<HTMLElement | null>(null);
let invChart: echarts.ECharts | null = null;
let storageChart: echarts.ECharts | null = null;
let valueChart: echarts.ECharts | null = null;
const stats = reactive({
  electronics: 0,
  clothing: 0,
  home: 0,
  books: 0,
});
const totalInventory = ref(0);
const showCards = ref(true);

const updateStatsAndChart = () => {
  const data = (tableData.value as any[]) || [];
  const categories = ["Electronics", "Clothing", "Home", "Books"];
  const counts = [0, 0, 0, 0];
  const stocks = [0, 0, 0, 0];
  for (const item of data) {
    const idx = categories.indexOf(item.category);
    if (idx >= 0) {
      counts[idx] = (counts[idx] ?? 0) + 1;
      const s =
        typeof item.stock === "number" ? item.stock : Number(item.stock || 0);
      stocks[idx] = (stocks[idx] ?? 0) + (isNaN(s) ? 0 : s);
    }
  }
  stats.electronics = counts[0] ?? 0;
  stats.clothing = counts[1] ?? 0;
  stats.home = counts[2] ?? 0;
  stats.books = counts[3] ?? 0;
  // Calculate total inventory
  totalInventory.value =
    (stocks[0] ?? 0) + (stocks[1] ?? 0) + (stocks[2] ?? 0) + (stocks[3] ?? 0);
  // 动态计算颜色：第一个是1，后面根据数据量动态设置步长，数据量大时最小步长0.05
  const maxCount = Math.max(...counts);
  const step = maxCount > 20 ? 0.05 : 1 / counts.length;
  const colors = counts.map((_, i) => {
    const alpha = i === 0 ? 1 : Math.max(0.05, 1 - i * step);
    return `rgba(2, 17, 163, ${alpha})`;
  });

  const option: echarts.EChartsOption = {
    grid: { left: 24, right: 24, top: 28, bottom: 24 },
    tooltip: { trigger: "axis", axisPointer: { type: "none" } },
    xAxis: {
      type: "category",
      data: categories,
      axisLine: { show: false },
      axisTick: { show: false },
      axisLabel: {
        show: true,
        interval: 0,
        formatter: (value: string, index: number) => {
          return `{title|${value}}\n{sub|${counts[index]} items}`;
        },
        rich: {
          title: {
            color: "#000",
            fontWeight: 500,
            fontSize: 12,
            // padding: [0, 0, 6, 0],
            align: "center",
          },
          sub: {
            color: "#9A9A9A",
            // backgroundColor: "#F3F4F6",
            padding: [4, 8],
            // borderRadius: 12,
            fontSize: 12,
            align: "center",
          },
        },
      },
    },
    yAxis: {
      type: "value",
      axisLine: { show: false },
      splitLine: { show: false },
      axisLabel: { show: false },
    },
    series: [
      {
        name: "Count",
        type: "bar",
        data: counts,
        itemStyle: {
          color: (params: any) => colors[params.dataIndex] || "#60a5fa",
          borderRadius: [8, 8, 8, 8],
        },
        barWidth: "60%",
      },
    ],
  };
  if (!invChart && invChartRef.value) {
    invChart = echarts.init(invChartRef.value);
    window.addEventListener("resize", onResize);
  }
  if (invChart) invChart.setOption(option);

  const storageOption: echarts.EChartsOption = {
    title: {
      text: "50%\nAvailable",
      left: "center",
      top: "center",
      textStyle: {
        color: "#0211A3",
        fontSize: 16,
        fontWeight: "bold",
        lineHeight: 24,
      },
    },
    series: [
      {
        type: "pie",
        radius: ["60%", "90%"],
        center: ["50%", "50%"],
        avoidLabelOverlap: false,
        label: { show: false },
        labelLine: { show: false },
        data: [{ value: 100, name: "Full", itemStyle: { color: "#0211A31A" } }],
        silent: true,
        z: 1,
      },
      {
        type: "pie",
        radius: ["60%", "90%"],
        center: ["50%", "50%"],
        avoidLabelOverlap: false,
        label: { show: false },
        labelLine: { show: false },
        data: [
          {
            value: 50,
            name: "Available",
            itemStyle: { color: "#0211A3", borderRadius: "50%" },
          },
          { value: 50, name: "Used", itemStyle: { color: "transparent" } },
        ],
        silent: true,
        animationType: "scale",
        animationEasing: "elasticOut",
        z: 2,
      },
    ],
  };
  if (!storageChart && storageChartRef.value) {
    storageChart = echarts.init(storageChartRef.value);
  }
  if (storageChart) storageChart.setOption(storageOption);

  const valueOption: echarts.EChartsOption = {
    grid: { left: 10, right: 10, top: 10, bottom: 10 },
    xAxis: {
      type: "category",
      boundaryGap: false,
      show: false,
      data: Array.from({ length: 24 }).map((_, i) => i),
    },
    yAxis: { type: "value", show: false },
    series: [
      {
        type: "line",
        smooth: true,
        data: Array.from({ length: 24 }).map((_, i) =>
          Math.round(50 + 20 * Math.sin(i / 3)),
        ),
        areaStyle: { color: "rgba(99, 102, 241, 0.25)" },
        lineStyle: { color: "#60a5fa" },
      },
    ],
  };
  if (!valueChart && valueChartRef.value) {
    valueChart = echarts.init(valueChartRef.value);
  }
  if (valueChart) valueChart.setOption(valueOption);
};

const onResize = () => {
  if (invChart) invChart.resize();
  if (storageChart) storageChart.resize();
  if (valueChart) valueChart.resize();
};

const fetchData = async () => {
  const company =
    (currentFilters.value as any)?.company ??
    authStore.currentCompany ??
    (await authStore.ensureCompany()) ??
    "";
  if (!company) {
    loading.value = false;
    tableData.value = [];
    total.value = 0;
    return;
  }
  loading.value = true;
  try {
    const raw = await getInboundList({
      company,
      page: page.value,
      pageSize: limit.value,
      ...currentFilters.value,
    }).send();
    const { data: rows, total: n } = parseOmsBillingListResult(raw);
    total.value = n;
    const fmt = (v: any) => `$${Number(v ?? 0).toFixed(2)}`;
    const toDate = (v: any) => (v ? String(v).slice(0, 10) : "-");
    tableData.value = rows.map((row: any) => ({
      id: row.name,
      inboundId: row.name || row.material_request || "-",
      completionDate: toDate(row.inbound_date),
      warehouse: row.company || row.pricing_plan || "-",
      totalAmount: fmt(row.total_cost_usd),
      palletQty: Number(row.pallet_qty ?? 0),
      palletPrice: fmt(row.pallet_unit_price_usd),
      palletSubtotal: fmt(row.pallet_amount_usd),
      boxQty: Number(row.box_qty ?? 0),
      boxPrice: fmt(row.box_unit_price_usd),
      boxSubtotal: fmt(row.box_amount_usd),
      scanQty: Number(row.scan_oms_qty ?? 0),
      scanPrice: fmt(row.scan_oms_unit_price_usd),
      scanSubtotal: fmt(row.scan_oms_amount_usd),
      grandTotal: fmt(row.total_cost_usd),
      ...row,
    }));
    await nextTick();
    updateStatsAndChart();
  } catch (error) {
    console.error("Failed to fetch inbound list:", error);
    tableData.value = [];
    total.value = 0;
  } finally {
    loading.value = false;
  }
};

onMounted(async () => {
  await nextTick();
  if (filterRef.value) {
    currentFilters.value = filterRef.value.getSearchParams();
  }
  loadData();
  fetchData();
});

onBeforeUnmount(() => {
  window.removeEventListener("resize", onResize);
  if (invChart) {
    invChart.dispose();
    invChart = null;
  }
  if (storageChart) {
    storageChart.dispose();
    storageChart = null;
  }
  if (valueChart) {
    valueChart.dispose();
    valueChart = null;
  }
});
</script>
<style lang="less" scoped>
.card {
  padding: 4px;
  color: #fff;
  border-radius: 12px;
  overflow: hidden;
  background: linear-gradient(131deg, #16215b 26.84%, #0a123c 98.1%);
  box-shadow: 0 1px 3px 0 rgba(0, 0, 0, 0.06);
  box-sizing: border-box;
}
</style>
