<template>
  <div class="p-6 space-y-6">
    <div class="flex flex-wrap items-end justify-between gap-4">
      <div class="space-y-1">
        <h2 class="text-[28px] leading-9 font-bold text-black">
          Orders <span class="text-[#6B6B6B] font-semibold">/ Action Required</span>
        </h2>
        <p class="text-sm font-medium text-[#6B6B6B]">
          Resolve flagged orders and move them back into normal processing flow.
        </p>
      </div>
      <el-button type="primary" class="!h-10 !px-4" @click="handleCreateOrder">
        <el-icon class="mr-1"><Plus /></el-icon>
        Create Order
      </el-button>
    </div>

    <el-alert
      type="error"
      show-icon
      :closable="false"
      title="Action Required orders need immediate handling to avoid fulfillment delay."
      class="!rounded-xl !border !border-[#F5C2C7] !bg-[#FDF2F4]"
    />

    <div class="bg-white rounded-xl border border-[#ECECEC] shadow-sm overflow-hidden">
      <div class="px-4 py-3 bg-[#F1F1F1] border-b border-[#ECECEC] flex flex-wrap gap-3 items-center">
        <el-input
          v-model="filters.keyword"
          class="required-search !w-[368px] max-w-full"
          placeholder="Search by Order ID, Platform ID, SKU..."
          :prefix-icon="Search"
          clearable
          @input="handleDebouncedSearch"
          @clear="handleImmediateSearch"
        />
        <el-select v-model="filters.quickRange" class="!w-[150px]" @change="handleImmediateSearch">
          <el-option label="Last 7 days" value="last7" />
          <el-option label="Last 30 days" value="last30" />
          <el-option label="This month" value="thisMonth" />
          <el-option label="All time" value="all" />
        </el-select>
        <el-date-picker
          v-model="filters.dateRange"
          type="daterange"
          range-separator="-"
          start-placeholder="Start Date"
          end-placeholder="End Date"
          value-format="YYYY-MM-DD"
          class="!w-[250px]"
          @change="handleImmediateSearch"
        />
        <el-select v-model="filters.stage" class="!w-[180px]" clearable placeholder="Stage" @change="handleImmediateSearch">
          <el-option label="Review & Fix" value="Review & Fix" />
          <el-option label="Warehouse Processing" value="Warehouse Processing" />
          <el-option label="Labeling" value="Labeling" />
          <el-option label="Export Processing" value="Export Processing" />
        </el-select>
        <el-select v-model="filters.status" class="!w-[170px]" clearable placeholder="Status" @change="handleImmediateSearch">
          <el-option label="Awaiting Approval" value="Awaiting Approval" />
          <el-option label="Need Attention" value="Need Attention" />
          <el-option label="Processing" value="Processing" />
          <el-option label="Blocked" value="Blocked" />
        </el-select>
        <el-button class="!h-10 !w-10 !px-0" @click="openAdvancedFilterDialog">
          <el-icon><Operation /></el-icon>
        </el-button>
      </div>

      <div class="px-4 py-3 border-b border-[#ECECEC]">
        <el-segmented
          v-model="filters.segmented"
          :options="segmentedOptions"
          size="large"
          @change="handleImmediateSearch"
        />
      </div>

      <el-table
        v-loading="loading"
        :data="listData"
        row-key="id"
        class="required-table"
        :header-cell-style="{ background: '#F1F1F1', color: '#000000', fontWeight: '600' }"
        @expand-change="handleExpandChange"
      >
        <el-table-column type="expand" width="44">
          <template #default="{ row }">
            <div
              v-loading="!!expandLoadingMap[row.id]"
              class="bg-[#FAFAFA] rounded-lg border border-[#ECECEC] m-4 p-4 space-y-3"
            >
              <div class="grid grid-cols-2 gap-3 text-sm">
                <div class="flex justify-between">
                  <span class="text-[#6B6B6B]">SKU</span>
                  <span class="font-semibold text-black">{{ getExpandedDetail(row).sku }}</span>
                </div>
                <div class="flex justify-between">
                  <span class="text-[#6B6B6B]">Quantity</span>
                  <span class="font-semibold text-black">{{ getExpandedDetail(row).quantity }}</span>
                </div>
                <div class="flex justify-between col-span-2">
                  <span class="text-[#6B6B6B]">Product</span>
                  <span class="font-semibold text-black">{{ getExpandedDetail(row).productName }}</span>
                </div>
                <div class="flex justify-between col-span-2">
                  <span class="text-[#6B6B6B]">Issue Summary</span>
                  <span class="font-semibold text-black">{{ getExpandedDetail(row).issueSummary || 'No issue' }}</span>
                </div>
              </div>
              <div class="flex justify-end gap-2">
                <el-button size="small" @click="openDetailDialog(row)">View Detail</el-button>
                <el-button size="small" type="primary" @click="openReviewDialog(row)">Review & Fix</el-button>
              </div>
            </div>
          </template>
        </el-table-column>

        <el-table-column label="Order ID / Platform ID" min-width="270">
          <template #default="{ row }">
            <div class="font-semibold text-black">{{ row.orderId }}</div>
            <div class="text-xs text-[#6B6B6B] mt-1">{{ row.platformId }}</div>
          </template>
        </el-table-column>
        <el-table-column prop="stage" label="Stages" min-width="170" />
        <el-table-column label="Status" min-width="180">
          <template #default="{ row }">
            <el-tag effect="plain" class="!rounded-md" :type="statusTagType(row.status)">
              {{ row.status }}
            </el-tag>
            <div v-if="row.statusNote" class="text-xs text-[#6B6B6B] mt-1">{{ row.statusNote }}</div>
          </template>
        </el-table-column>
        <el-table-column label="Customer" min-width="170">
          <template #default="{ row }">
            <div class="text-sm text-black">{{ row.customerName }}</div>
            <div class="text-xs text-[#6B6B6B] mt-1">{{ row.customerRegion }}</div>
          </template>
        </el-table-column>
        <el-table-column label="Inventory" width="130" align="center">
          <template #default="{ row }">
            <el-tag effect="plain" class="!rounded-md" :type="inventoryTagType(row.inventoryStatus)">
              {{ row.inventoryStatus }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column label="Date" width="170">
          <template #default="{ row }">
            <div class="text-xs text-[#6B6B6B]">Create: {{ row.createDate }}</div>
            <div class="text-xs text-[#6B6B6B] mt-1">Due: {{ row.dueDate }}</div>
          </template>
        </el-table-column>
        <el-table-column label="Actions" width="180" align="right">
          <template #default="{ row }">
            <div class="flex items-center justify-end gap-2">
              <el-button size="small" type="primary" @click="openReviewDialog(row)">Review & Fix</el-button>
              <el-dropdown trigger="click" @command="(command: any) => handleRowCommand(command)">
                <el-button class="!h-8 !w-8 !p-0 !border-[#16215B1A]">
                  <el-icon><MoreFilled /></el-icon>
                </el-button>
                <template #dropdown>
                  <el-dropdown-menu>
                    <el-dropdown-item :command="{ action: 'view', row }">
                      <el-icon class="mr-2"><View /></el-icon>
                      View Detail
                    </el-dropdown-item>
                    <el-dropdown-item :command="{ action: 'awaiting', row }">
                      <el-icon class="mr-2"><Timer /></el-icon>
                      Mark Awaiting
                    </el-dropdown-item>
                    <el-dropdown-item :command="{ action: 'processing', row }">
                      <el-icon class="mr-2"><CircleCheck /></el-icon>
                      Mark Processing
                    </el-dropdown-item>
                    <el-dropdown-item :command="{ action: 'blocked', row }">
                      <el-icon class="mr-2"><WarningFilled /></el-icon>
                      Mark Blocked
                    </el-dropdown-item>
                    <el-dropdown-item :command="{ action: 'ticket', row }">
                      <el-icon class="mr-2"><Headset /></el-icon>
                      Create Ticket
                    </el-dropdown-item>
                  </el-dropdown-menu>
                </template>
              </el-dropdown>
            </div>
          </template>
        </el-table-column>
      </el-table>

      <div class="p-4 border-t border-[#ECECEC] flex flex-wrap gap-4 items-center justify-between">
        <div class="text-sm text-[#6B6B6B]">Total {{ total }} action required orders</div>
        <el-pagination
          v-model:current-page="pagination.page"
          v-model:page-size="pagination.pageSize"
          :total="total"
          layout="prev, pager, next"
          background
        />
      </div>
    </div>

    <el-dialog v-model="reviewVisible" title="Review & Fix" width="560px" destroy-on-close>
      <el-form :model="reviewForm" label-position="top">
        <el-form-item label="Issue Type">
          <el-select v-model="reviewForm.issueType" class="w-full">
            <el-option label="Address Error" value="Address Error" />
            <el-option label="Info Missing" value="Info Missing" />
            <el-option label="Wrong Declaration" value="Wrong Declaration" />
            <el-option label="Inventory Mismatch" value="Inventory Mismatch" />
            <el-option label="Payment Risk" value="Payment Risk" />
          </el-select>
        </el-form-item>
        <el-form-item label="Due Date">
          <el-date-picker v-model="reviewForm.dueDate" value-format="YYYY-MM-DD" type="date" class="w-full" />
        </el-form-item>
        <el-form-item label="Details">
          <el-input v-model="reviewForm.note" type="textarea" :rows="4" placeholder="Describe required fixes..." />
        </el-form-item>
      </el-form>
      <template #footer>
        <div class="flex justify-end gap-3">
          <el-button @click="reviewVisible = false">Cancel</el-button>
          <el-button type="primary" @click="submitReview">Submit</el-button>
        </div>
      </template>
    </el-dialog>

    <el-dialog v-model="detailVisible" title="Order Detail" width="680px" destroy-on-close>
      <div class="space-y-3 text-sm">
        <div class="grid grid-cols-2 gap-x-6 gap-y-3">
          <div class="flex justify-between border-b border-[#ECECEC] pb-2">
            <span class="text-[#6B6B6B]">Order ID</span>
            <span class="font-semibold text-black">{{ detailRecord?.orderId || '--' }}</span>
          </div>
          <div class="flex justify-between border-b border-[#ECECEC] pb-2">
            <span class="text-[#6B6B6B]">Platform ID</span>
            <span class="font-semibold text-black">{{ detailRecord?.platformId || '--' }}</span>
          </div>
          <div class="flex justify-between border-b border-[#ECECEC] pb-2">
            <span class="text-[#6B6B6B]">Stage</span>
            <span class="font-semibold text-black">{{ detailRecord?.stage || '--' }}</span>
          </div>
          <div class="flex justify-between border-b border-[#ECECEC] pb-2">
            <span class="text-[#6B6B6B]">Status</span>
            <span class="font-semibold text-black">{{ detailRecord?.status || '--' }}</span>
          </div>
          <div class="flex justify-between border-b border-[#ECECEC] pb-2">
            <span class="text-[#6B6B6B]">Issue Type</span>
            <span class="font-semibold text-black">{{ detailRecord?.issueType || '--' }}</span>
          </div>
          <div class="flex justify-between border-b border-[#ECECEC] pb-2">
            <span class="text-[#6B6B6B]">Due Date</span>
            <span class="font-semibold text-black">{{ detailRecord?.dueDate || '--' }}</span>
          </div>
          <div class="flex justify-between border-b border-[#ECECEC] pb-2 col-span-2">
            <span class="text-[#6B6B6B]">Issue Summary</span>
            <span class="font-semibold text-black">{{ detailRecord?.issueSummary || '--' }}</span>
          </div>
        </div>
      </div>
      <template #footer>
        <div class="flex justify-end gap-3">
          <el-button @click="detailVisible = false">Close</el-button>
          <el-button type="primary" @click="detailRecord && openReviewDialog(detailRecord)">Review & Fix</el-button>
        </div>
      </template>
    </el-dialog>

    <el-dialog v-model="ticketVisible" title="Create Ticket" width="520px" destroy-on-close>
      <el-form :model="ticketForm" label-position="top">
        <el-form-item label="Subject">
          <el-input v-model="ticketForm.subject" />
        </el-form-item>
        <el-form-item label="Priority">
          <el-select v-model="ticketForm.priority" class="w-full">
            <el-option label="High" value="High" />
            <el-option label="Medium" value="Medium" />
            <el-option label="Low" value="Low" />
          </el-select>
        </el-form-item>
        <el-form-item label="Message">
          <el-input v-model="ticketForm.message" type="textarea" :rows="4" />
        </el-form-item>
      </el-form>
      <template #footer>
        <div class="flex justify-end gap-3">
          <el-button @click="ticketVisible = false">Cancel</el-button>
          <el-button type="primary" @click="submitTicket">Create</el-button>
        </div>
      </template>
    </el-dialog>

    <el-dialog v-model="advancedFilterVisible" title="Advanced Filters" width="520px" destroy-on-close>
      <el-form :model="advancedFilterForm" label-position="top">
        <el-form-item label="Inventory">
          <el-select v-model="advancedFilterForm.inventory" class="w-full" clearable>
            <el-option label="In Stock" value="In Stock" />
            <el-option label="Reserved" value="Reserved" />
            <el-option label="Out of Stock" value="Out of Stock" />
          </el-select>
        </el-form-item>
      </el-form>
      <template #footer>
        <div class="flex justify-end gap-3">
          <el-button @click="advancedFilterVisible = false">Cancel</el-button>
          <el-button type="primary" @click="applyAdvancedFilter">Apply</el-button>
        </div>
      </template>
    </el-dialog>
  </div>
</template>

<script setup lang="ts">
import { computed, onBeforeUnmount, onMounted, reactive, ref } from 'vue'
import { useRequest } from 'alova/client'
import { ElMessage } from 'element-plus'
import {
  CircleCheck,
  Headset,
  MoreFilled,
  Operation,
  Plus,
  Search,
  Timer,
  View,
  WarningFilled
} from '@element-plus/icons-vue'
import {
  createRequiredSupportTicket,
  getActionRequiredFromTickets,
  getRequiredOrderDetail,
  submitRequiredReview,
  updateRequiredOrderStatus,
  type RequiredIssueType,
  type RequiredInventoryStatus,
  type RequiredOrderRecord,
  type RequiredOrderStage,
  type RequiredOrderStatus
} from '@/api/orderRequired'
import { useAuthStore } from '@/store/modules/auth'

const authStore = useAuthStore()

const pagination = reactive({
  page: 1,
  pageSize: 10
})

const filters = reactive<{
  keyword: string
  quickRange: 'last7' | 'last30' | 'thisMonth' | 'all'
  dateRange: [string, string] | []
  stage: RequiredOrderStage | ''
  status: RequiredOrderStatus | ''
  segmented: 'awaiting' | 'process' | 'error'
  inventory: RequiredInventoryStatus | ''
}>({
  keyword: '',
  quickRange: 'last7',
  dateRange: [],
  stage: '',
  status: '',
  segmented: 'awaiting',
  inventory: ''
})

const reviewVisible = ref(false)
const detailVisible = ref(false)
const ticketVisible = ref(false)
const advancedFilterVisible = ref(false)
const activeRowId = ref('')
const detailRecord = ref<RequiredOrderRecord | null>(null)
const expandLoadingMap = reactive<Record<string, boolean>>({})
const expandDetailMap = reactive<Record<string, RequiredOrderRecord>>({})

const reviewForm = reactive({
  issueType: 'Address Error' as RequiredIssueType,
  dueDate: '',
  note: ''
})

const ticketForm = reactive({
  subject: '',
  priority: 'High' as 'High' | 'Medium' | 'Low',
  message: ''
})

const advancedFilterForm = reactive({
  inventory: '' as RequiredInventoryStatus | ''
})

// Action Required：Draft 订单 + TT Open 未关闭关联订单；有 TT 时显示 TT 标题(subject)
const { data: ticketsRaw, loading, send: fetchList } = useRequest(
  () =>
    getActionRequiredFromTickets({
      company: (authStore.currentCompany ?? authStore.company ?? '').trim() || '',
      limit: 500
    }),
  { immediate: false }
)

/** 接口原始响应 → 表格行 + 分段统计；客户端过滤 + 分页 slice */
const derivedFromTickets = computed(() => {
  const raw = ticketsRaw.value as any
  if (raw == null) {
    return {
      total: 0,
      list: [] as RequiredOrderRecord[],
      segmented: { awaiting: 0, process: 0, error: 0 }
    }
  }
  const payload = raw?.message ?? raw
  const rawList = Array.isArray(payload?.data) ? payload.data : []
  const fullList: RequiredOrderRecord[] = rawList.map((o: any) => ({
    id: o.name ?? '',
    orderId: o.name ?? '',
    platformId: o.trouble_ticket ?? '',
    stage: 'Review & Fix' as RequiredOrderStage,
    status: (o.status === 'Open' || o.status === 'In Progress' || o.status === 'Waiting Reply'
      ? 'Need Attention'
      : o.status) as RequiredOrderStatus,
    statusNote: (o.subject ?? '').trim(),
    issueType: 'Address Error' as RequiredIssueType,
    issueSummary: (o.subject ?? '').trim(),
    customerName: '-',
    customerRegion: '',
    inventoryStatus: 'In Stock' as RequiredInventoryStatus,
    createDate: '-',
    dueDate: '-',
    sku: '-',
    productName: '-',
    quantity: 0
  }))
  // Client-side filters: segmented, keyword, status
  let filtered = fullList
  if (filters.segmented === 'awaiting') {
    filtered = filtered.filter((r) => r.status === 'Awaiting Approval')
  } else if (filters.segmented === 'process') {
    filtered = filtered.filter((r) => r.status === 'Processing')
  } else if (filters.segmented === 'error') {
    filtered = filtered.filter((r) => r.status === 'Need Attention')
  }
  const kw = (filters.keyword ?? '').trim().toLowerCase()
  if (kw) {
    filtered = filtered.filter(
      (r) =>
        (r.orderId ?? '').toLowerCase().includes(kw) ||
        (r.platformId ?? '').toLowerCase().includes(kw) ||
        (r.statusNote ?? '').toLowerCase().includes(kw)
    )
  }
  if (filters.status) {
    filtered = filtered.filter((r) => r.status === filters.status)
  }
  const totalCount = filtered.length
  const start = (pagination.page - 1) * pagination.pageSize
  const list = filtered.slice(start, start + pagination.pageSize)
  const awaiting = fullList.filter((r) => r.status === 'Awaiting Approval').length
  const process = fullList.filter((r) => r.status === 'Processing').length
  const error = fullList.filter((r) => r.status === 'Need Attention').length
  return {
    total: totalCount,
    list,
    segmented: { awaiting, process, error }
  }
})

const { send: fetchOrderDetail } = useRequest((id: string) => getRequiredOrderDetail(id, authStore.currentCompany ?? undefined), {
  immediate: false
})

const { send: postReview } = useRequest(
  (payload: { id: string; issueType: RequiredIssueType; note: string; dueDate: string }) =>
    submitRequiredReview({ ...payload, company: authStore.currentCompany ?? undefined }),
  { immediate: false }
)

const { send: postStatus } = useRequest(
  (payload: { id: string; status: RequiredOrderStatus }) =>
    updateRequiredOrderStatus({ ...payload, company: authStore.currentCompany ?? undefined }),
  { immediate: false }
)

const { send: postTicket } = useRequest(
  (payload: { id: string; subject: string; message: string; priority: 'High' | 'Medium' | 'Low' }) =>
    createRequiredSupportTicket({ ...payload, company: authStore.currentCompany ?? undefined }),
  { immediate: false }
)

const listData = computed(() => derivedFromTickets.value.list)
const total = computed(() => derivedFromTickets.value.total)

const segmentedOptions = computed(() => {
  const segmented = derivedFromTickets.value.segmented || { awaiting: 0, process: 0, error: 0 }
  return [
    { label: `Awaiting (${String(segmented.awaiting).padStart(2, '0')})`, value: 'awaiting' },
    { label: `Process (${String(segmented.process).padStart(2, '0')})`, value: 'process' },
    { label: `Error (${String(segmented.error).padStart(2, '0')})`, value: 'error' }
  ]
})

let searchTimer: ReturnType<typeof setTimeout> | null = null

const statusTagType = (status: RequiredOrderStatus) => {
  if (status === 'Awaiting Approval') return 'warning'
  if (status === 'Need Attention') return 'danger'
  if (status === 'Processing') return 'success'
  return 'info'
}

const inventoryTagType = (status: RequiredInventoryStatus) => {
  if (status === 'In Stock') return 'success'
  if (status === 'Reserved') return 'warning'
  return 'danger'
}

const getExpandedDetail = (row: RequiredOrderRecord) => {
  return expandDetailMap[row.id] || row
}

const handleDebouncedSearch = () => {
  if (searchTimer) clearTimeout(searchTimer)
  searchTimer = setTimeout(() => {
    pagination.page = 1
  }, 300)
}

const handleImmediateSearch = () => {
  pagination.page = 1
}

const mapDetailApiToRecord = (row: RequiredOrderRecord, apiData: any): RequiredOrderRecord => {
  const first = Array.isArray(apiData?.items) && apiData.items[0] ? apiData.items[0] : null
  return {
    ...row,
    orderId: apiData?.name ?? row.orderId,
    platformId: row.platformId,
    status: (apiData?.status ?? row.status) as RequiredOrderStatus,
    dueDate: apiData?.delivery_date ? String(apiData.delivery_date).slice(0, 10) : row.dueDate,
    issueSummary: (apiData?.remarks ?? row.issueSummary ?? '').trim() || row.issueSummary || '-',
    sku: first?.item_code ?? row.sku ?? '-',
    productName: first?.item_name ?? row.productName ?? '-',
    quantity: first?.qty ?? row.quantity ?? 0
  }
}

const handleExpandChange = async (row: RequiredOrderRecord, expandedRows: RequiredOrderRecord[]) => {
  const expanded = expandedRows.some((item) => item.id === row.id)
  if (!expanded || expandDetailMap[row.id] || expandLoadingMap[row.id]) return
  expandLoadingMap[row.id] = true
  try {
    const res = (await fetchOrderDetail(row.id)) as any
    const wrapped = res?.message ?? res
    const apiData = wrapped?.ok && wrapped?.data ? wrapped.data : null
    expandDetailMap[row.id] = apiData ? mapDetailApiToRecord(row, apiData) : row
  } finally {
    expandLoadingMap[row.id] = false
  }
}

const openReviewDialog = (row: RequiredOrderRecord) => {
  activeRowId.value = row.id
  reviewForm.issueType = row.issueType || 'Address Error'
  reviewForm.dueDate = row.dueDate
  reviewForm.note = row.issueSummary || ''
  reviewVisible.value = true
}

const openDetailDialog = async (row: RequiredOrderRecord) => {
  try {
    const res = (await fetchOrderDetail(row.id)) as any
    const wrapped = res?.message ?? res
    const apiData = wrapped?.ok && wrapped?.data ? wrapped.data : null
    detailRecord.value = apiData ? mapDetailApiToRecord(row, apiData) : row
  } catch {
    detailRecord.value = row
  }
  detailVisible.value = true
}

const openAdvancedFilterDialog = () => {
  advancedFilterForm.inventory = filters.inventory
  advancedFilterVisible.value = true
}

const applyAdvancedFilter = () => {
  filters.inventory = advancedFilterForm.inventory
  advancedFilterVisible.value = false
  handleImmediateSearch()
}

const updateStatus = async (row: RequiredOrderRecord, status: RequiredOrderStatus, message: string, type: 'success' | 'warning') => {
  await postStatus({ id: row.id, status })
  if (type === 'success') ElMessage.success(message)
  if (type === 'warning') ElMessage.warning(message)
  fetchList()
}

const handleRowCommand = async (payload: { action: string; row: RequiredOrderRecord }) => {
  const command = payload.action
  const row = payload.row
  if (command === 'view') {
    await openDetailDialog(row)
    return
  }
  if (command === 'awaiting') {
    await updateStatus(row, 'Awaiting Approval', 'Order marked as Awaiting Approval', 'warning')
    return
  }
  if (command === 'processing') {
    await updateStatus(row, 'Processing', 'Order updated to Processing', 'success')
    return
  }
  if (command === 'blocked') {
    await updateStatus(row, 'Blocked', 'Order marked as Blocked', 'warning')
    return
  }
  activeRowId.value = row.id
  ticketForm.subject = `${row.orderId} action-required follow-up`
  ticketForm.message = row.issueSummary || ''
  ticketVisible.value = true
}

const submitReview = async () => {
  if (!activeRowId.value) return
  if (!reviewForm.note.trim()) {
    ElMessage.warning('Please enter fix details')
    return
  }
  await postReview({
    id: activeRowId.value,
    issueType: reviewForm.issueType,
    note: reviewForm.note,
    dueDate: reviewForm.dueDate
  })
  reviewVisible.value = false
  ElMessage.success('Review request submitted')
  fetchList()
}

const submitTicket = async () => {
  if (!activeRowId.value) return
  if (!ticketForm.message.trim()) {
    ElMessage.warning('Please enter ticket details')
    return
  }
  await postTicket({
    id: activeRowId.value,
    subject: ticketForm.subject,
    message: ticketForm.message,
    priority: ticketForm.priority
  })
  ticketVisible.value = false
  ElMessage.success('Ticket created')
}

const handleCreateOrder = () => {
  ElMessage.success('Create Order modal is coming next step')
}

onMounted(() => {
  fetchList()
})

onBeforeUnmount(() => {
  if (searchTimer) clearTimeout(searchTimer)
})
</script>

<style scoped>
.required-table :deep(.el-table__inner-wrapper::before) {
  display: none;
}

.required-table :deep(.el-table__row td) {
  border-bottom: 1px solid #ececec;
}

.required-search :deep(.el-input__wrapper) {
  border-width: 1.5px;
}
</style>
